﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class BoardManager : MonoBehaviour
{
    private const float TILE_SIZE = 1.0f;
    private const float TILE_OFFSET = 0.5f;

    private int SELECTIONX = -1;
    private int SELECTIONY = -1;  

    public List<GameObject> chessmanPrefabs;
    private List<GameObject> activeChessman = new List<GameObject>();

    private Quaternion orientation = Quaternion.Euler(0, 180, 0);

    private void Start()
    {
        SpawnAllChessmans(); 
    }

    private void Update()
    {
        UpdateSelection();
        DrawChessboard();
    }

    private void UpdateSelection()
    {
        if (!Camera.main)
            return;

        RaycastHit hit;

        if (Physics.Raycast(Camera.main.ScreenPointToRay(Input.mousePosition), out hit, 25.0f, LayerMask.GetMask("ChessPlane")))
        {
            SELECTIONX = (int)hit.point.x;
            SELECTIONY = (int)hit.point.z;
        }
        else
        {
            SELECTIONX = -1;
            SELECTIONY = -1;
        }
    }

    private void SpawnChessman(int index, Vector3 position)
    {
        GameObject go = Instantiate(chessmanPrefabs[index], position, orientation) as GameObject;
        go.transform.SetParent(transform);
        activeChessman.Add(go);
    }

    private void SpawnAllChessmans()
    {
        activeChessman = new List<GameObject>();

        //Biali
        SpawnChessman(2, GetTileCenter(3, 0)); //Król
        SpawnChessman(3, GetTileCenter(4, 0)); //Królowa
        SpawnChessman(5, GetTileCenter(0, 0)); //Wieże
        SpawnChessman(5, GetTileCenter(7, 0));
        SpawnChessman(0, GetTileCenter(2, 0)); //Gońce
        SpawnChessman(0, GetTileCenter(5, 0));
        SpawnChessman(1, GetTileCenter(1, 0)); //Konie
        SpawnChessman(1, GetTileCenter(6, 0));
        for (int i = 0; i < 8; i++)
        {
            SpawnChessman(4, GetTileCenter(i, 1));  //Pionki
        }

        //Czarni
        SpawnChessman(8, GetTileCenter(3, 7)); //Król
        SpawnChessman(9, GetTileCenter(4, 7)); //Królowa
        SpawnChessman(11, GetTileCenter(0, 7)); //Wieże
        SpawnChessman(11, GetTileCenter(7, 7));
        SpawnChessman(6, GetTileCenter(2, 7)); //Gońce
        SpawnChessman(6, GetTileCenter(5, 7));
        SpawnChessman(7, GetTileCenter(1, 7)); //Konie
        SpawnChessman(7, GetTileCenter(6, 7));
        for (int i = 0; i < 8; i++)
        {
            SpawnChessman(10, GetTileCenter(i, 6));  //Pionki
        }
    }

    private Vector3 GetTileCenter(int x, int y)
    {
        Vector3 origin = Vector3.zero;
        origin.x += (TILE_SIZE * x) + TILE_OFFSET;
        origin.z += (TILE_SIZE * y) + TILE_OFFSET;
        origin.y = 0.4f;
        return origin;
    }

    private void DrawChessboard()
    {
        Vector3 widthLine = Vector3.right * 8;
        Vector3 heightLine = Vector3.forward * 8;

        for (int i = 0; i <= 8; i++)
        {
            Vector3 start = Vector3.forward * i;
            Debug.DrawLine(start, start + widthLine);
            for (int j = 0; j <= 8; j++)
            {
                start = Vector3.right * j;
                Debug.DrawLine(start, start + heightLine);
            }
        }

        if(SELECTIONX >= 0 && SELECTIONY >= 0)
        {
            Debug.DrawLine(Vector3.forward * SELECTIONY + Vector3.right * SELECTIONX, Vector3.forward * (SELECTIONY + 1) + Vector3.right * (SELECTIONX + 1));

            Debug.DrawLine(Vector3.forward * (SELECTIONY + 1) + Vector3.right * SELECTIONX, Vector3.forward * SELECTIONY + Vector3.right * (SELECTIONX +1));
        }
    }
}

