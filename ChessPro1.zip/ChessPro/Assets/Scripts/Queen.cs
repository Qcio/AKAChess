﻿using UnityEngine;
using System.Collections;

public class Queen : Chessman
{

}

