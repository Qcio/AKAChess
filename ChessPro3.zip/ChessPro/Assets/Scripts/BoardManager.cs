﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class BoardManager : MonoBehaviour
{
    public static BoardManager Instance { set; get; } //
    private bool[,] allowedMoves { set; get; } //

    public Chessman[,] Chessmans { set; get; }
    private Chessman selectedChessman;

    private const float TILE_SIZE = 1.0f;
    private const float TILE_OFFSET = 0.5f;

    private int SELECTIONX = -1;
    private int SELECTIONY = -1;  

    public List<GameObject> chessmanPrefabs;
    private List<GameObject> activeChessman = new List<GameObject>();

    private Quaternion orientation = Quaternion.Euler(0, 180, 0);

    public bool isWhiteTurn = true;

    private void Start()
    {
        Instance = this;
        SpawnAllChessmans(); 
    }

    private void Update()
    {
        UpdateSelection();
        DrawChessboard();


        if (Input.GetMouseButtonDown(0))
        {
            if (SELECTIONX >= 0 && SELECTIONY >= 0)
            {
                if (selectedChessman == null)
                {
                    //select the chessman
                    SelectChessman(SELECTIONX, SELECTIONY);
                }
                else
                {
                    //move the chessman
                    MoveChessman(SELECTIONX, SELECTIONY);
                }
            }
        }
    }

    private void SelectChessman(int x, int y)
    {
        if (Chessmans[x, y] == null)
            return;

        if (Chessmans[x, y].isWhite != isWhiteTurn)
            return;

        //
        allowedMoves = Chessmans[x, y].PossibleMove();
        selectedChessman = Chessmans[x, y];
        BoardHighlights.Instance.HighlightAllowedMoves(allowedMoves);
        //
    }

    private void MoveChessman(int x, int y)
    {
        if (allowedMoves[x,y]) //
        {
            Chessman c = Chessmans[x, y];

            if(c != null && c.isWhite != isWhiteTurn) 
            {
                if(c.GetType() == typeof(King)) 
                {
                    //Koniec gry
                    return;
                }

                activeChessman.Remove(c.gameObject);
                Destroy(c.gameObject); 
            } //

            Chessmans[selectedChessman.CurrentX, selectedChessman.CurrentY] = null;
            selectedChessman.transform.position = GetTileCenter(x, y);
            selectedChessman.SetPosition(x, y);
            Chessmans[x, y] = selectedChessman;
            isWhiteTurn = !isWhiteTurn;
        }

        BoardHighlights.Instance.HideHighlights();  //
        selectedChessman = null;
    }

    private void UpdateSelection()
    {
        if (!Camera.main)
            return;

        RaycastHit hit;

        if (Physics.Raycast(Camera.main.ScreenPointToRay(Input.mousePosition), out hit, 25.0f, LayerMask.GetMask("ChessPlane")))
        {
            SELECTIONX = (int)hit.point.x;
            SELECTIONY = (int)hit.point.z;
        }
        else
        {
            SELECTIONX = -1;
            SELECTIONY = -1;
        }
    }

    private void SpawnChessman(int index, int x, int y)
    {
        GameObject go = Instantiate(chessmanPrefabs[index], GetTileCenter(x,y), orientation) as GameObject;
        go.transform.SetParent(transform);
        Chessmans[x, y] = go.GetComponent<Chessman>();
        Chessmans[x, y].SetPosition(x, y);
        activeChessman.Add(go);
    }

    private void SpawnAllChessmans()
    {
        activeChessman = new List<GameObject>();
        Chessmans = new Chessman[8, 8];

        //Biali
        SpawnChessman(2, 3, 0); //Król
        SpawnChessman(3, 4, 0); //Królowa
        SpawnChessman(5, 0, 0); //Wieże
        SpawnChessman(5, 7, 0);
        SpawnChessman(0, 2, 0); //Gońce
        SpawnChessman(0, 5, 0);
        SpawnChessman(1, 1, 0); //Konie
        SpawnChessman(1, 6, 0);
        for (int i = 0; i < 8; i++)
        {
            SpawnChessman(4, i, 1);  //Pionki
        }

        //Czarni
        SpawnChessman(8, 4, 7); //Król     //Zamienione pozycje czarnego króla i królowej
        SpawnChessman(9, 3, 7); //Królowa  //
        SpawnChessman(11, 0, 7); //Wieże
        SpawnChessman(11, 7, 7);
        SpawnChessman(6, 2, 7); //Gońce
        SpawnChessman(6, 5, 7);
        SpawnChessman(7, 1, 7); //Konie
        SpawnChessman(7, 6, 7);
        for (int i = 0; i < 8; i++)
        {
            SpawnChessman(10, i, 6);  //Pionki
        }
    }

    private Vector3 GetTileCenter(int x, int y)
    {
        Vector3 origin = Vector3.zero;
        origin.x += (TILE_SIZE * x) + TILE_OFFSET;
        origin.z += (TILE_SIZE * y) + TILE_OFFSET;
        origin.y = 0.4f;
        return origin;
    }

    private void DrawChessboard()
    {
        Vector3 widthLine = Vector3.right * 8;
        Vector3 heightLine = Vector3.forward * 8;

        for (int i = 0; i <= 8; i++)
        {
            Vector3 start = Vector3.forward * i;
            Debug.DrawLine(start, start + widthLine);
            for (int j = 0; j <= 8; j++)
            {
                start = Vector3.right * j;
                Debug.DrawLine(start, start + heightLine);
            }
        }

        if(SELECTIONX >= 0 && SELECTIONY >= 0)
        {
            Debug.DrawLine(Vector3.forward * SELECTIONY + Vector3.right * SELECTIONX, Vector3.forward * (SELECTIONY + 1) + Vector3.right * (SELECTIONX + 1));

            Debug.DrawLine(Vector3.forward * (SELECTIONY + 1) + Vector3.right * SELECTIONX, Vector3.forward * SELECTIONY + Vector3.right * (SELECTIONX +1));
        }
    }
}

