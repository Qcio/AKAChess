﻿using UnityEngine;
using System.Collections;

public class King : Chessman
{

}
