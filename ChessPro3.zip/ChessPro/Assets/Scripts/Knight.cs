﻿using UnityEngine;
using System.Collections;

public class Knight : Chessman
{
    
}
